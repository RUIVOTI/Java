public class Curso {
   private int Iddocurso;
   private String Nomedocurso;
   private String Nomedoprofessor;
   private  int Cargahoraria;
   

public Curso (int Iddocurso, String Nomedocurso, String Nomedoprofessor, int Cargahoraria){

    this.Iddocurso = Iddocurso;
    this.Nomedocurso = Nomedocurso;
    this.Nomedoprofessor = Nomedoprofessor;
    this.Cargahoraria = Cargahoraria;

}
public int getIddocurso() {
    return Iddocurso;
}

public String getNomedocurso() {
    return Nomedocurso;
}

public String getNomedoprofessor() {
    return Nomedoprofessor;
}
public int getCargahoraria(){
    return Cargahoraria;
}

public void setIddocurso(int Iddocurso) {
    this.Iddocurso = Iddocurso;
}

public void setNomedocurso(String Nomedocurso) {
    this.Nomedocurso = Nomedocurso;
}

public void setNomedoprofessor(String Nomedoprofessor) {
    this.Nomedoprofessor = Nomedoprofessor;
}

public void setCargahoraria(int Cargahoraria) {
    this.Cargahoraria = Cargahoraria;
}

}


  
