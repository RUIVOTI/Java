public class Pessoa {
    private  String nome;
    private double peso;
    private double estatura;
    private int idade;
    private String cordosolhos;
    private String cordocabelo;
    Curso curso;

public Pessoa( String nome, int idade, double peso, double estatura, String cordosolhos, String cordocabelo ) {
    this.nome = nome;
    this.idade = idade;
    this.peso = peso;
    this.estatura = estatura;
    this.cordosolhos = cordosolhos;
    this.cordocabelo =  cordocabelo;
}
void  Curso(Curso curso){
    this.curso = curso;
}
public String getNome() {
    return nome;
}

public int getIdade() { 
    return idade;
}

public double getPeso() {
    return peso;
}
public String getcordosolhos(){
    return cordosolhos;
}
public String getcordocabelo(){
    return cordocabelo;
}

public double getEstatura() {
    return estatura;
}

public void setNome(String nome) {
    this.nome = nome;
}

public void setIdade(int idade) {
    this.idade = idade;
}

public void setPeso(double peso) {
    this.peso = peso;
}

public void setEstatura(double estatura) {
    this.estatura = estatura;
}
public void setcordosolhos(String cordosolhos){
    this.cordosolhos = cordosolhos;
}
public void setcordocabelo(String cordocabelo){
    this.cordocabelo = cordocabelo;
}
}