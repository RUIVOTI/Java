public class DefinePessoa {
    public static void main(String[] args) {
      
        Pessoa pessoa = new Pessoa("João", 30, 80.0, 1.80, "castanho", "Ruivo");
        Pessoa pessoa2 = new Pessoa("Lucas", 21, 70, 1.70, "Azul", "Loiro ");
        Pessoa pessoa3 = new Pessoa("Gabriel"  , 19, 65, 1.62, "Castanho", "Preto");
        Pessoa pessoa4 = new Pessoa("Leonardo" , 55, 85, 1.76, "Castanho", "Branco");
        Pessoa pessoa5 = new Pessoa("Felipe", 16, 45, 1.70, "Verde", "Azul");


        pessoa.setNome("José");
        pessoa.setIdade(40);
        pessoa.setPeso(85.0);
        pessoa.setEstatura(1.75);
        pessoa.setcordocabelo("Ruivo" );
        pessoa.setcordosolhos("castanho");
        
        System.out.println("______________________________________________________________________________________________________\n");

        System.out.println("Olá meu nome é: "+pessoa.getNome() +  ". Tenho: "+pessoa.getIdade() + "anos, " + pessoa.getEstatura() + "mts e peso: " +pessoa.getPeso()+ "kg,  Cor do Cabelo: " +pessoa.getcordocabelo()+  ", Cor dos olhos: "+pessoa.getcordosolhos() );

            Curso primeirapessoa = new Curso(10, "Tecnico em informatica", "Luis", 1200);
            primeirapessoa.setIddocurso(10);
            primeirapessoa.setNomedocurso("Tecnico em Informatica ");
            primeirapessoa.setNomedoprofessor("Luis");
            primeirapessoa.setCargahoraria(1200);
            System.out.println("Id do curso: "+primeirapessoa.getIddocurso()+ ", Nome do Curso:"+primeirapessoa.getNomedocurso()+ ", Nome Do Professor: " +primeirapessoa.getNomedoprofessor()+ ", Carga Horaria: "+primeirapessoa.getCargahoraria());
        
        
        pessoa2.setNome("Lucas");
        pessoa2.setIdade(21);
        pessoa2.setPeso(70);
        pessoa2.setEstatura(1.70);
        pessoa2.setcordocabelo("Loiro" );
        pessoa2.setcordosolhos("Azul");

        System.out.println("______________________________________________________________________________________________________- \n");        System.out.println("Olá meu nome é: "+pessoa2.getNome() +  ". Tenho: "+pessoa2.getIdade() + "anos, " + pessoa2.getEstatura() + "mts e peso: " +pessoa2.getPeso()+ "kg, Cor do Cabelo: " +pessoa2.getcordocabelo()+ ", Cor dos Olhos: " +pessoa2.getcordosolhos() );

        Curso segundapessoa = new Curso(1000, "Tecnico em Eletrotecnico", "Carlos", 1200);
            segundapessoa.setIddocurso(1000);
            segundapessoa.setNomedocurso("Tecnico em Eltrotecnico");
            segundapessoa.setNomedoprofessor("Carlos");
            segundapessoa.setCargahoraria(1200);
            System.out.println("Id do curso: "+segundapessoa.getIddocurso()+ ", Nome do Curso: "+segundapessoa.getNomedocurso()+ ", Nome Do Professor: " +segundapessoa.getNomedoprofessor()+ ", Carga Horaria: "+segundapessoa.getCargahoraria());

        System.out.println("______________________________________________________________________________________________________\n");

        pessoa3.setNome("Gabriel");
        pessoa3.setIdade(19);
        pessoa3.setPeso(65);
        pessoa3.setEstatura(1.62);
        pessoa3.setcordocabelo("Preto" );
        pessoa3.setcordosolhos("Castanho");

        System.out.println("Olá meu nome é: "+pessoa3.getNome() +  ". Tenho: "+pessoa3.getIdade() + "anos, " + pessoa3.getEstatura() + "mts e peso: " +pessoa3.getPeso()+ "kg, Cor do Cabelo: " +pessoa3.getcordocabelo()+ ", Cor dos Olhos: " +pessoa3.getcordosolhos() );

        Curso terceirapessoa = new Curso(555, "Tecnico em Eletroeletrônica", "Carlos", 1500);
            terceirapessoa.setIddocurso(555);
            terceirapessoa.setNomedocurso("Tecnico em Eletromecânica");
            terceirapessoa.setNomedoprofessor("José");
            terceirapessoa.setCargahoraria(1500);
            System.out.println("Id do curso: "+terceirapessoa.getIddocurso()+ ", Nome do Curso: "+terceirapessoa.getNomedocurso()+ ", Nome Do Professor: " +terceirapessoa.getNomedoprofessor()+ ", Carga Horaria: "+terceirapessoa.getCargahoraria());

        System.out.println("______________________________________________________________________________________________________\n");

        pessoa4.setNome("Leonardo");
        pessoa4.setIdade(55);
        pessoa4.setPeso(85);
        pessoa4.setEstatura(1.76);
        pessoa4.setcordocabelo("Branco" );
        pessoa4.setcordosolhos("Castanho");

        System.out.println("Olá meu nome é: "+pessoa4.getNome() +  ". Tenho: "+pessoa4.getIdade() + "anos, " + pessoa4.getEstatura() + "mts e peso: " +pessoa4.getPeso()+ "kg, Cor do Cabelo: " +pessoa4.getcordocabelo()+ ", Cor dos Olhos: " +pessoa4.getcordosolhos() );

        Curso quartapessoa = new Curso(635, "Tecnico em Manutenção Automotiva", "Luan", 700);
            quartapessoa.setIddocurso(635);
            quartapessoa.setNomedocurso("Tecnico em Manutenção Automotiva");
            quartapessoa.setNomedoprofessor("Luan");
            quartapessoa.setCargahoraria(700);
            System.out.println("Id do curso: "+quartapessoa.getIddocurso()+ ", Nome do Curso: "+quartapessoa.getNomedocurso()+ ", Nome Do Professor: " +quartapessoa.getNomedoprofessor()+ ", Carga Horaria: "+quartapessoa.getCargahoraria());

        System.out.println("______________________________________________________________________________________________________\n");

        pessoa5.setNome("Felipe");
        pessoa5.setIdade(16);
        pessoa5.setPeso(45);
        pessoa5.setEstatura(1.70);
        pessoa5.setcordocabelo("Azul" );
        pessoa5.setcordosolhos("Verde");


        System.out.println("Olá meu nome é: "+pessoa5.getNome() +  ". Tenho: "+pessoa5.getIdade() + "anos, " + pessoa5.getEstatura() + "mts e peso: " +pessoa5.getPeso()+ "kg, Cor do Cabelo: " +pessoa5.getcordocabelo()+ ", Cor dos Olhos: " +pessoa5.getcordosolhos() );

        Curso quintapessoa = new Curso(120, "Tecnico em Infraestrutura", "Samuel", 2000);
        quintapessoa.setIddocurso(120);
        quintapessoa.setNomedocurso("Tecnico em Infraestrutura");
        quintapessoa.setNomedoprofessor("Samuel");
        quintapessoa.setCargahoraria(2000);

        System.out.println("Id do curso: "+quintapessoa.getIddocurso()+ ", Nome do Curso: "+quintapessoa.getNomedocurso()+ ", Nome Do Professor: " +quintapessoa.getNomedoprofessor()+ ", Carga Horaria: "+quintapessoa.getCargahoraria());

        System.out.println("______________________________________________________________________________________________________-");
}
}
